
import (
     "banco de dados / sql" 
    "log" 
    "net / http" 
    "texto / modelo"

    _ "github.com/go-sql-driver/mysql"
)

tipo Employee struct {
    Id     int
    String de nome
    Corda da cidade
}

func dbConn () (db * sql.DB) {
    dbDriver : =  "mysql" 
    dbUser : =  "root" 
    dbPass : =  "a17m10t55" 
    dbName : =  "db_equipamentos" 
    db, erro : = sql.Open (dbDriver, dbUser + ":" + dbPass + "@ /" + dbName)
     se errar ! = nulo {
        pânico (err. Erro ())
    }
    retornar db
}

var tmpl = template.Must (template.ParseGlob ( "form / *" ))

func Index (w http.ResponseWriter, r * http.Request) {
    db : = dbConn ()
    selDB, err : = db.Query ( "SELECT * FROM Employee ORDER BY id DESC" )
     se errar ! = nulo {
        pânico (err. Erro ())
    }
    emp : = Employee {}
    res : = [] Employee {}
     para selDB.Next () {
         var id int 
        var  nome , cadeia de cidade
        err = selDB.Scan ( & id, & name , & city)
         se errar ! = nulo {
            pânico (err. Erro ())
        }
        emp.Id = id
        emp.Name =  name 
        emp.City = city
        res = append (res, emp)
    }
    tmpl.ExecuteTemplate (w, "Index" , res)
    adiar db.Close ()
}

func Show (w http.ResponseWriter, r * http.Request) {
    db : = dbConn ()
    nId : = r. URL .Query (). Get ( "id" )
    selDB, err : = db.Query ( "SELECT * FROM Empregado WHERE id =?" , nId)
     se errar ! = nulo {
        pânico (err. Erro ())
    }
    emp : = Employee {}
     para selDB.Next () {
         var id int 
        var  nome , cidade string
        err = selDB.Scan ( & id, & name , & city)
         se errar ! = nulo {
            pânico (err. Erro ())
        }
        emp.Id = id
        emp.Name =  name 
        emp.City = city
    }
    tmpl.ExecuteTemplate (w, "Show" , emp)
    adiar db.Close ()
}

func New (w http.ResponseWriter, r * http.Request) {
    tmpl.ExecuteTemplate (w, "New" , nil)
}

func Editar (w http.ResponseWriter, r * http.Request) {
    db : = dbConn ()
    nId : = r. URL .Query (). Get ( "id" )
    selDB, err : = db.Query ( "SELECT * FROM Empregado WHERE id =?" , nId)
     se errar ! = nulo {
        pânico (err. Erro ())
    }
    emp : = Employee {}
     para selDB.Next () {
         var id int 
        var  nome , cidade string
        err = selDB.Scan ( & id, & name , & city)
         se errar ! = nulo {
            pânico (err. Erro ())
        }
        emp.Id = id
        emp.Name =  name 
        emp.City = city
    }
    tmpl.ExecuteTemplate (w, "Edit" , emp)
    adiar db.Close ()
}

func Insert (w http.ResponseWriter, r * http.Request) {
    db : = dbConn ()
     se r.Method = =  "POST" {
         name  : = r.FormValue ( "name" )
        city : = r.FormValue ( "cidade" )
        insForm, err : = db.Prepare ( "INSERT INTO Employee (nome, cidade) VALUES (?,?)" )
         if err ! = nulo {
            pânico (err. Erro ())
        }
        insForm.Exec ( nome , cidade)
         log .Println ( "INSERT: Nome:"  +  nome  +  "| Cidade:"  + cidade)
    }
    adiar db.Close ()
    http.Redirect (w, r, "/" , 301 )
}

func Update (w http.ResponseWriter, r * http.Request) {
    db : = dbConn ()
     se r.Method = =  "POST" {
         name  : = r.FormValue ( "name" )
        city : = r.FormValue ( "cidade" )
        id : = r.FormValue ( "uid" )
        insForm, err : = db.Prepare ( "UPDATE Employee SET nome = ?, cidade =? WHERE id =?" )
         se errar ! = nulo {
            pânico (err. Erro ())
        }
        insForm.Exec ( nome , cidade, id)
         log .Println ( "UPDATE: Nome:"  +  nome  +  "| Cidade:"  + cidade)
    }
    adiar db.Close ()
    http.Redirect (w, r, "/" , 301 )
}

func Delete (w http.ResponseWriter, r * http.Request) {
    db : = dbConn ()
    emp : = r. URL .Query (). Get ( "id" )
    delForm, err : = db.Prepare ( "APAGAR DE Empregado WHERE id =?" )
     se errar ! = nulo {
        pânico (err. Erro ())
    }
    delForm.Exec (emp)
    log .Println ( "DELETE" )
    adiar db.Close ()
    http.Redirect (w, r, "/" , 301 )
}

func main () {
    log .Println ( "Servidor iniciado em: http: // localhost: 8080" )
    http.HandleFunc ( "/" , índice)
    http.HandleFunc ( "/ show" , Mostrar)
    http.HandleFunc ( "/ new" , novo)
    http.HandleFunc ( "/ edit" , Edit)
    http.HandleFunc ( "/ insert" , Insert)
    http.HandleFunc ( "/ update" , atualização)
    http.HandleFunc ( "/ delete" , Delete)
    http.ListenAndServe ( ": 8080" , nada)
}